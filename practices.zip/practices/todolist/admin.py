from django.contrib import admin

# Register your models here.

from .models import tobedone

admin.site.register(tobedone)
